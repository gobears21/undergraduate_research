#!/bin/bash

# set environment variable for neoSYCL-bench

GCC_HOME=/opt/gcc-8.2.0
PATH=$GCC_HOME/bin:$PATH
LD_LIBRARY_PATH=$GCC_HOME/lib:$GCC_HOME/lib64:$LD_LIBRARY_PATH

export PATH LD_LIBRARY_PATH

export CC=gcc
export CXX=g++
