#ifndef CUSTOM_SYCL_INCLUDE_SYCL_SYCL_H_
#define CUSTOM_SYCL_INCLUDE_SYCL_SYCL_H_

#include "neoSYCL/sycl.hpp"

namespace cl::sycl {

using namespace neosycl::sycl;

}

#endif //CUSTOM_SYCL_INCLUDE_SYCL_SYCL_H_

