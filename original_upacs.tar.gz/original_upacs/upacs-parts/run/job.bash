#!/bin/bash
#SBATCH --partition aurora
#SBATCH --gres=ve:1

./run
